export class Payment {
    billingNumber!: number;
    price!: number;
    cardNumber!: number;
    cvv!: number;
    taxes!: number;
    quantity!: string;
    date!: string;
    totalBill!: number;
    
    constructor(){

    }


}
