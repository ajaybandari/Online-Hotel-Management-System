import { Managestaff } from './managestaff';

describe('Managestaff', () => {
  it('should create an instance', () => {
    expect(new Managestaff()).toBeTruthy();
  });
});
