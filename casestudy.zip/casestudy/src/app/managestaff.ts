export class Managestaff {
    code:number | undefined;
    employeeName:string | undefined;
    employeeAddress:string | undefined;
    NIC:number | undefined;
    salary:number | undefined;
    age:number | undefined;
    occupation:string | undefined;
    email:string | undefined;
    constructor(){
        
    }
}
