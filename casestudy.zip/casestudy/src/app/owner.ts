export class Owner {
    userId!:string;
    password!:string;
}
