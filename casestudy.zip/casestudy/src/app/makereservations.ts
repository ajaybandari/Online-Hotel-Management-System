export class Makereservations {
     code:number | undefined;
     numberofChildren:number | undefined;
     numberofAdults:number | undefined;
     checkinDate:string | undefined;
     checkoutDate:string | undefined;
     status:string | undefined;
     numberofNights:number | undefined;

     constructor(){}




}
