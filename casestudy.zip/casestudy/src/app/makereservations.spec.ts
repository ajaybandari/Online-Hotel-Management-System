import { Makereservations } from './makereservations';

describe('Makereservations', () => {
  it('should create an instance', () => {
    expect(new Makereservations()).toBeTruthy();
  });
});
