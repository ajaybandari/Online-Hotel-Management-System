import { Component, OnInit } from '@angular/core';
import { Makereservations } from '../makereservations';
import { MakereservationsService } from '../makereservations.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})
export class LoginsuccessComponent implements OnInit {
 reservation =new Makereservations();
  constructor(private makeReservationService:MakereservationsService) {
    // this.reserveRoom();
   }

  ngOnInit(): void {
  }

  reserveRoom(regirsterForm: { value: any; }){
    this.makeReservationService.reserveRoom(regirsterForm.value).subscribe(
     (response) =>{
      console.log(response);
      this.reserveRoom(regirsterForm);
  },
  (error)=>{
    console.log(error);
  }
  );





  }

  getRoomDetails(regirsterForm: { value: any; }){
    this.makeReservationService.reserveRoom(regirsterForm.value).subscribe(
      (response)=>{
        console.log(response);
      },
      (error)=>{
        console.log(error);
      }
    )
  }

}

