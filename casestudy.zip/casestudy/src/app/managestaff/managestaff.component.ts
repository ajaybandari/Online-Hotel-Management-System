import { Component, OnInit } from '@angular/core';
import { NgForm,NgModel } from '@angular/forms';
import { Managestaff } from '../managestaff';
import { ManagestaffService } from '../managestaff.service';
@Component({
  selector: 'app-managestaff',
  templateUrl: './managestaff.component.html',
  styleUrls: ['./managestaff.component.css']
})
export class ManagestaffComponent implements OnInit {
 staff = new Managestaff();
 staffDetails =null;
  constructor(private manageStaffService:ManagestaffService) {
    this.getEmployeeDetails();
   }

  ngOnInit(): void {
  }
  

  register(regirsterForm: { value: any; }){
    this.manageStaffService.addEmployee(regirsterForm.value).subscribe(
      (response) =>{
        console.log(response);
        this.getEmployeeDetails();
      },
      (err) =>{
        console.log(err);

      }
    );

  }
  getEmployeeDetails(){
    this.manageStaffService.getEMployee().subscribe(
      (response) =>{
        console.log(response);
        // this.getEmployeeDetails();
      },
      (error) =>{
        console.log(error);
      }
    )
  }

}
