export class User {
    id:number | undefined;
    emailId:string | undefined;
    userName:string | undefined;
    password:string | undefined;
    constructor( )
    {
        // this.id=id;
        // this.emailId=emailId;
        // this.userName=userName;
        // this.password=password;
    }

}
